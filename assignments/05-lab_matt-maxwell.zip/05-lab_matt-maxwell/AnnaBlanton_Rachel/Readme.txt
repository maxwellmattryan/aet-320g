Raw multitrack excerpt from Anna Blanton's 'Rachel'. This file is provided for educational purposes only, and the material contained in it should not be used for any commercial purpose without the express permission of the copyright holders. Please refer to https://creativecommons.org/licenses/by-sa/4.0/ and www.cambridge-mt.com for further licensing details.

Comprises 8 WAV files at 24-bit/44.1kHz resolution.

Tempo: approx 63.5bpm.